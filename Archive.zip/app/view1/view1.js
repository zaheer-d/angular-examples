'use strict';

angular.module('myApp.view1', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view1', {
    templateUrl: 'view1/view1.html',
    controller: 'View1Ctrl'
  });
}])

.controller('View1Ctrl', ['$scope','$http', 'weatherService', function($scope, $http, weatherService) {

  var now = moment(new Date());
  var format = 'HH:mm';

  $scope.Now = now.format('DD MMM YYYY');
  $scope.Time = now.format('HH:mm');

  $scope.init = function() {
    var ny = now.clone().tz('America/New_York').format();
    //var data = null;

    weatherService.data().success(function(res){
      var data = res;
      console.log(data);

      $scope.owmCapeTown = data.list[0];
      $scope.owmKiev = data.list[1];
      $scope.owmNewYork = data.list[2];
    });
  };

  $scope.updateTime = function(){
    now = moment($scope.Now + $scope.Time, 'DD MMM YYYY HH:mm');
    console.log('new time ---> ' + now);
  };


  $scope.newYork = function(){
    // console.log('----->  newYork');
    return now.clone().tz('America/New_York').format(format);
  };

  $scope.capeTown = function(){
    // console.log('----->  capeTown');
  //  var now = moment(new Date());
    return now.clone().tz('Africa/Johannesburg').format(format);
  };

  $scope.kiev = function(){
    // console.log('----->  kiev');
   // var now = moment(new Date());
    return now.clone().tz('Europe/Kiev').format(format);
  };

  $scope.init();

}]);