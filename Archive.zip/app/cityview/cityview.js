/**
 * controller for the city view
 */
'use strict';

angular.module('myApp.cityview', ['ngRoute'])

    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/cityview/:id', {
            templateUrl: '/cityview/cityview.html',
            controller: 'CityCtrl'
        });
    }])

    .controller('CityCtrl', ['$scope', '$routeParams', 'holidayService',
        function ($scope, $params, holidayService) {
            $scope.calendarOptions = {
                defaultDate: Date.now(),
                minDate: new Date(),
                maxDate: new Date([2020, 12, 31]),
                dayNamesLength: 1, // How to display weekdays (1 for "M", 2 for "Mo", 3 for "Mon"; 9 will show full day names; default is 1)
                multiEventDates: true, // Set the calendar to render multiple events in the same day or only one event, default is false
                maxEventsPerDay: 1 // Set how many events should the calendar display before showing the 'More Events' message, default is 3;
                //eventClick: $scope.eventClick,
                //dateClick: $scope.dateClick
            };

            // $scope.events = [
            //     {title: 'NY', date: new Date([2015, 12, 31])},
            //     {title: 'ID', date: new Date([2015, 6, 4])}
            // ];

            // console.log('------>' +$params.id);
            if ($params.id === 'capetown') {
                $scope.Name = 'Cape Town';
                $scope.ImageHeader = '/images/Cape-town.jpg';

                holidayService.SouthAfrica().success(function (data) {
                    var filterData = [];
                    data.forEach(function(item){
                        var dtHoliday = new Date(item.date);
                        if (dtHoliday >= Date.now())
                        {
                            var newItem = {title:item.name, date:item.date};
                            filterData.push(newItem);
                        }
                    });
                    $scope.events = filterData;
                });

            }

            if ($params.id === 'newyork') {
                $scope.Name = 'New York';
                $scope.ImageHeader = '/images/new-york.jpg';

                holidayService.USA().success(function (data) {
                    var filterData = [];
                    data.forEach(function(item){
                        var dtHoliday = new Date(item.date);
                        if (dtHoliday >= Date.now())
                        {
                            var newItem = {title:item.name, date:item.date};
                            filterData.push(newItem);
                            //filterData.push(item);
                        }
                    });
                    $scope.events = filterData;
                    //$scope.Holidays = filterData;
                    // $scope.Holidays = res;
                });
            }

            if ($params.id === 'kiev') {
                $scope.Name = 'Kiev';
                $scope.ImageHeader = '/images/kiev.jpg';
            }

        }]);