/**
 * Created by user on 2016/09/18.
 */
'use strict';

/**
 * @ngdoc service
 * @name myApp.weatherservice
 * @description
 * # weatherservice
 * Service in the servicesApp.
 */
angular.module('myApp')
    .factory('weatherService', ['$http', function ($http) {

        // AngularJS will instantiate a singleton by calling "new" on this function
      return{

        data : function(){
          //var res = null;
          return $http.get('../data/weather.json').
          success(function(data){
              // this.CapeTown = data.list[0];
              // this.Kiev = data.list[1];
              // this.NewYork = data.list[2];
              //console.log('----- DATASERVICE> '+ JSON.stringify(data.list[1]));
              // results = data;
              //console.log(data);
              return data;
          }).
          error(function(err){
              console.log('Error loading weather data'+err);
              return err;
          });

          //return res;
      }
      };
    }]);
