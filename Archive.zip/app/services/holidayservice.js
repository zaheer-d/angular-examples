/**
 * Created by user on 2016/09/26.
 */
/**
 * Created by user on 2016/09/18.
 */
'use strict';

/**
 * @ngdoc service
 * @name myApp.weatherservice
 * @description
 * # weatherservice
 * Service in the servicesApp.
 */
angular.module('myApp')
    .factory('holidayService', ['$http', function ($http) {

        // AngularJS will instantiate a singleton by calling "new" on this function
        return{

            USA : function(){
                //var res = null;
                return $http.get('../data/usa.json').
                success(function(data){
                    // this.CapeTown = data.list[0];
                    // this.Kiev = data.list[1];
                    // this.NewYork = data.list[2];
                    //console.log('----- DATASERVICE> '+ JSON.stringify(data.list[1]));
                    // results = data;
                    //console.log(data);
                    var filterData = [];
                    data.forEach(function(item){
                        var dtHoliday = Date(item.date);
                        if (dtHoliday >= Date.now())
                        {
                            filterData.push(item);
                        }
                    });

                    return filterData;
                }).
                error(function(err){
                    console.log('Error loading weather data'+err);
                    return err;
                });

                //return res;
            },
            SouthAfrica : function(){
            //var res = null;
            return $http.get('../data/southafrica.json').
            success(function(data){
                // this.CapeTown = data.list[0];
                // this.Kiev = data.list[1];
                // this.NewYork = data.list[2];
                //console.log('----- DATASERVICE> '+ JSON.stringify(data.list[1]));
                // results = data;
                //console.log(data);
                //return data;

                var filterData = [];
                data.forEach(function(item){
                    var dtHoliday = Date(item.date);
                    if (dtHoliday >= Date.now())
                    {
                        filterData.push(item);
                    }
                });

                return filterData;
            }).
            error(function(err){
                console.log('Error loading weather data'+err);
                return err;
            });

            //return res;
        }
        };
    }]);
